The socketing code for the ROV project
