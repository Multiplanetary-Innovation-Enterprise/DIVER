class Server():
    def __init__(self, port):
        pass


    def close(self):
        pass
