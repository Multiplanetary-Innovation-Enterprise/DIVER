The Messaging code for the ROV project
