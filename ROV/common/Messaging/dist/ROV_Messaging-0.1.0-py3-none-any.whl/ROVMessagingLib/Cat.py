class Cat():
    def meow(self):
        print("Meow")
